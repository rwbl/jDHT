Copy jDHT.jar, jDHTxml and dht.jar to the B4J additional libraries folder.

Copy libdht.so to the dirapp folder.
