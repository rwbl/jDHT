package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends Object{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4a.StandardBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) throws Exception{
        try {
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            ba.raiseEvent(null, "appstart", (Object)args);
        } catch (Throwable t) {
			BA.printException(t, true);
		
        } finally {
            anywheresoftware.b4a.keywords.Common.LogDebug("Program terminated (StartMessageLoop was not called).");
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static de.rwbl.dht.dht _dht11 = null;
public static de.rwbl.dht.dht _dht22 = null;
public static anywheresoftware.b4a.objects.Timer _timer1 = null;
public static String  _appstart(String[] _args) throws Exception{
 //BA.debugLineNum = 39;BA.debugLine="Sub AppStart (Args() As String)";
 //BA.debugLineNum = 40;BA.debugLine="Log(\"AppStart\")";
anywheresoftware.b4a.keywords.Common.Log("AppStart");
 //BA.debugLineNum = 42;BA.debugLine="dht22.Initialize(22, 23)";
_dht22._initialize(ba,(int) (22),(int) (23));
 //BA.debugLineNum = 44;BA.debugLine="timer1.Initialize(\"timer1\", 2000)";
_timer1.Initialize(ba,"timer1",(long) (2000));
 //BA.debugLineNum = 45;BA.debugLine="timer1.Enabled = True";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 46;BA.debugLine="StartMessageLoop";
anywheresoftware.b4a.keywords.Common.StartMessageLoop(ba);
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 33;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 34;BA.debugLine="Private dht11 As DHT";
_dht11 = new de.rwbl.dht.dht();
 //BA.debugLineNum = 35;BA.debugLine="Private dht22 As DHT";
_dht22 = new de.rwbl.dht.dht();
 //BA.debugLineNum = 36;BA.debugLine="Private timer1 As Timer";
_timer1 = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return "";
}
public static String  _timer1_tick() throws Exception{
 //BA.debugLineNum = 49;BA.debugLine="Sub timer1_tick";
 //BA.debugLineNum = 50;BA.debugLine="Log($\"DHT22 ${DateTime.Time(DateTime.Now)}: ${dht";
anywheresoftware.b4a.keywords.Common.Log(("DHT22 "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(anywheresoftware.b4a.keywords.Common.DateTime.Time(anywheresoftware.b4a.keywords.Common.DateTime.getNow())))+": "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_dht22._temperature()))+"*, "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_dht22._humidity()))+"%"));
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return "";
}
}
