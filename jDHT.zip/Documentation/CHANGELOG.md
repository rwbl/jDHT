Changelog jDHT

20170601(v1.01)
* NEW: DHT22 MQTT example
* UPD: Minor changes

20170306 (v1.00)
* NEW: First version with B4J non-UI example
